package com.Lista2.EstruturaDeDados;

public class Nodo {
    private int numero;
    private Nodo proximo;

    public Nodo() {
    }


    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Nodo getProximo() {
        return proximo;
    }

    public void setProximo(Nodo proximo) {
        this.proximo = proximo;
    }
}
